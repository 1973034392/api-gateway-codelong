# ✅哪些语言有GC机制

很多编程语言都有垃圾回收（GC）机制，其中包括：

1. Java
2. C#
3. Python
4. Ruby
5. JavaScript
6. Kotlin
7. Swift
8. Go
9. R
10. Lua

这些语言的 GC 机制都是在运行时自动管理内存，以防止内存泄漏和数据丢失。

> 更新: 2025-08-30 16:19:13  
> 原文: <https://www.yuque.com/hollis666/zuguif/xverku>