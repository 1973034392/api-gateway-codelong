# ✅SQL中PK、UK、CK、FK、DF是什么意思？

# 典型回答


K是Key的意思，就是代表约束的，所以PK、UK这些都是代表不同类型的约束：



PK：Primary Key ，主键约束

UK：Unique Key， 唯一约束

CK： check()， 检查约束

FK：Foreign Key， 外键约束

DF：default ，默认约束

> 更新: 2025-08-30 16:20:01  
> 原文: <https://www.yuque.com/hollis666/zuguif/ccen6bqh6pgsiogs>