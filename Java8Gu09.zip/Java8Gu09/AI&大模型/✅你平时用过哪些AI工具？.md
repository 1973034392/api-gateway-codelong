# ✅你平时用过哪些AI工具？

# 典型回答


初级回答：用过DeepSeek、文心一言、通义千问等国产对话式AI工具

中级回答：通过梯子用过国外的AI，如GPT等，并且付费过。

使用过通义灵码等免费编程工具。

高级回答：除了文字对话式AI以外，还用过其他的多模态类型的AI工具，比如Runway、DELL-E、Midjourney、Stable Diffusion、可灵等。

使用过Cursor等付费的编程工具。

牛逼回答：自己部署过AI模型，并尝试过做调优。

> 更新: 2025-08-30 16:19:37  
> 原文: <https://www.yuque.com/hollis666/zuguif/iyra527vlkcgfiqq>